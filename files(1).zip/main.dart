import 'package:flutter/material.dart';

void main() => runApp(InspirasiApp());

class InspirasiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inspirasiku',
      home: InspirasiHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class InspirasiHome extends StatefulWidget {
  @override
  _InspirasiHomeState createState() => _InspirasiHomeState();
}

class _InspirasiHomeState extends State<InspirasiHome> {
  final TextEditingController _temaController = TextEditingController();
  String? hasilKutipan;
  String? hasilGambarUrl;

  Future<void> generateMotivasi() async {
    setState(() {
      hasilKutipan = "Cinta sejati adalah ketika kebahagiaan orang lain lebih penting dari kebahagiaanmu sendiri.";
      hasilGambarUrl = "https://source.unsplash.com/600x400/?love,philosophy";
    });
    // Pada implementasi nyata, panggil API AI di sini
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inspirasiku'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.blue,
        elevation: 0,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Wujudkan motivasi harian Anda dengan kekuatan AI. Buat gambar dan video inspiratif dalam hitungan detik.",
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("Buat Gambar"),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: null,
                    child: Text("Buat Video"),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("Unggah Sendiri"),
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Generator Gambar & Kutipan AI",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  SizedBox(height: 6),
                  Text("Masukkan tema untuk menghasilkan beberapa kutipan dan gambar motivasi unik."),
                  SizedBox(height: 12),
                  TextField(
                    controller: _temaController,
                    decoration: InputDecoration(
                      hintText: "filsafat cinta",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: generateMotivasi,
                    child: Text("Buat Konten"),
                  ),
                ],
              ),
            ),
            if (hasilKutipan != null) ...[
              SizedBox(height: 18),
              Text("Kutipan Motivasi:", style: TextStyle(fontWeight: FontWeight.bold)),
              Text(hasilKutipan!, style: TextStyle(fontSize: 16)),
              SizedBox(height: 10),
              if (hasilGambarUrl != null)
                Image.network(hasilGambarUrl!, height: 180),
            ],
            Spacer(),
            Center(
              child: Text("Dibuat dengan ❤️ oleh AI", style: TextStyle(color: Colors.grey)),
            ),
          ],
        ),
      ),
    );
  }
}
async function generateStableDiffusionImage(tema) {
  const prompt = `Sebuah ilustrasi motivasi dengan tema "${tema}", gaya minimalis, warna cerah, sangat inspiratif`;
  const response = await axios.post(
    'https://api.replicate.com/v1/predictions',
    {
      version: "your-stable-diffusion-version-id", // Lihat di https://replicate.com/stability-ai/stable-diffusion
      input: { prompt }
    },
    {
      headers: {
        'Authorization': `Token ${process.env.REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json'
      }
    }
  );
  // Tunggu hingga status selesai (polling)
  let prediction = response.data;
  while (prediction.status !== "succeeded" && prediction.status !== "failed") {
    await new Promise(resolve => setTimeout(resolve, 2000));
    const poll = await axios.get(`https://api.replicate.com/v1/predictions/${prediction.id}`, {
      headers: { 'Authorization': `Token ${process.env.REPLICATE_API_TOKEN}` }
    });
    prediction = poll.data;
  }
  if (prediction.status === "succeeded") {
    return prediction.output[0];
  } else {
    throw new Error("Stable Diffusion gagal menghasilkan gambar.");
  }
}
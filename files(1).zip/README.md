# Motivasiku AI

Aplikasi Motivasi Harian Berbasis AI (OpenAI GPT + DALL·E/Stable Diffusion)  
- Backend: FastAPI (Python)
- Frontend: Flutter (APK build otomatis via GitHub Actions)
- Gambar motivasi: DALL·E 3 atau Stable Diffusion (Replicate)

## Struktur
- `/backend` : Backend FastAPI Python (API AI)
- `/app`     : Flutter app

## Deploy backend di Railway/Render
- Isi `.env` dari `.env.example`
- Deploy, backend siap pakai

## Build APK otomatis
- Lihat hasil build di menu Actions GitHub

## Penggunaan
1. Jalankan backend (`cd backend && uvicorn main:app --host 0.0.0.0 --port 3000`)
2. Jalankan Flutter (`cd app && flutter run`)
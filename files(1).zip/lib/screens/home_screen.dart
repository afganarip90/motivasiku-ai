import 'package:flutter/material.dart';
import '../widgets/motivasi_generator.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inspirasiku'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.blue,
        elevation: 0,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Wujudkan motivasi harian Anda dengan kekuatan AI. Buat gambar dan video inspiratif dalam hitungan detik.",
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("Buat Gambar"),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: null,
                    child: Text("Buat Video"),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("Unggah Sendiri"),
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),
            MotivasiGenerator(),
            Spacer(),
            Center(
              child: Text("Dibuat dengan ❤️ oleh AI", style: TextStyle(color: Colors.grey)),
            ),
          ],
        ),
      ),
    );
  }
}
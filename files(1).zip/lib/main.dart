import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(InspirasiApp());

class InspirasiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Inspirasiku',
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
import 'package:flutter/material.dart';
import '../services/ai_service.dart';

class MotivasiGenerator extends StatefulWidget {
  @override
  _MotivasiGeneratorState createState() => _MotivasiGeneratorState();
}

class _MotivasiGeneratorState extends State<MotivasiGenerator> {
  final TextEditingController _temaController = TextEditingController();
  String? hasilKutipan;
  String? hasilGambarUrl;
  String? errorMsg;
  bool loading = false;

  Future<void> generateMotivasi() async {
    setState(() {
      loading = true;
      hasilKutipan = null;
      hasilGambarUrl = null;
      errorMsg = null;
    });
    try {
      final result = await AIService.generateContent(_temaController.text.trim());
      setState(() {
        hasilKutipan = result['quote'];
        hasilGambarUrl = result['image'];
      });
    } catch (e) {
      setState(() {
        errorMsg = e.toString().replaceAll('Exception: ', '');
      });
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("Generator Gambar & Kutipan AI",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          SizedBox(height: 6),
          Text("Masukkan tema untuk menghasilkan beberapa kutipan dan gambar motivasi unik."),
          SizedBox(height: 12),
          TextField(
            controller: _temaController,
            decoration: InputDecoration(
              hintText: "filsafat cinta",
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.search),
            ),
            onSubmitted: (_) => generateMotivasi(),
          ),
          SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: loading ? null : generateMotivasi,
              child: loading
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                    )
                  : Text("Buat Konten"),
            ),
          ),
          if (errorMsg != null) ...[
            SizedBox(height: 18),
            Text(errorMsg!, style: TextStyle(color: Colors.red)),
          ],
          if (hasilKutipan != null && hasilKutipan!.isNotEmpty) ...[
            SizedBox(height: 18),
            Text("Kutipan Motivasi:", style: TextStyle(fontWeight: FontWeight.bold)),
            Text(hasilKutipan!, style: TextStyle(fontSize: 16)),
          ],
          if (hasilGambarUrl != null && hasilGambarUrl!.isNotEmpty) ...[
            SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                hasilGambarUrl!,
                height: 180,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    Text("Gambar gagal dimuat", style: TextStyle(color: Colors.grey)),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
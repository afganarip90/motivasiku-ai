import 'dart:convert';
import 'package:http/http.dart' as http;

class AIService {
  static const String backendUrl = 'http://<IP-OR-DOMAIN>:3000/generate'; // Ganti dengan IP/domain backend kamu

  static Future<Map<String, String>> generateContent(String tema) async {
    final response = await http.post(
      Uri.parse(backendUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'tema': tema}),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return {
        'quote': data['quote'] ?? '',
        'image': data['image'] ?? ''
      };
    } else {
      String errorMsg = 'Gagal mendapatkan motivasi';
      try {
        final data = jsonDecode(response.body);
        if (data['detail'] != null) {
          errorMsg = data['detail'];
        }
      } catch (_) {}
      throw Exception(errorMsg);
    }
  }
}
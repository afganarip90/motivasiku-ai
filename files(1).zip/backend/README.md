# Backend Motivasiku AI

- FastAPI + OpenAI untuk motivasi dan gambar AI
- Bisa pilih DALL·E atau Stable Diffusion (Replicate)

## .env
```
OPENAI_API_KEY=isi_api_key_openai
REPLICATE_API_TOKEN=isi_token_replicate (opsional, jika pakai Stable Diffusion)
```

## Install & Run
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 3000
```
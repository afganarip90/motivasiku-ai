from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import openai
import os
from dotenv import load_dotenv
import requests

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")
REPLICATE_API_TOKEN = os.getenv("REPLICATE_API_TOKEN")

app = FastAPI()

class TemaRequest(BaseModel):
    tema: str
    use_sd: bool = False  # jika mau pakai Stable Diffusion

def generate_sd_image(prompt):
    url = "https://api.replicate.com/v1/predictions"
    headers = {
        "Authorization": f"Token {REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
    }
    body = {
        "version": "a9758cb6bdf367f7e9ea2b4e7c7cf3b4f92d7c4cfb2943a4b5edc8c6c5e0e91a",  # SDXL 1.0
        "input": {"prompt": prompt}
    }
    resp = requests.post(url, headers=headers, json=body)
    prediction = resp.json()
    prediction_url = prediction["urls"]["get"]

    # Polling sampai selesai
    while True:
        poll = requests.get(prediction_url, headers=headers).json()
        if poll["status"] == "succeeded":
            return poll["output"][0]
        if poll["status"] == "failed":
            raise Exception("Stable Diffusion gagal")
        import time; time.sleep(2)

@app.post("/generate")
async def generate_motivasi(req: TemaRequest):
    if not req.tema or not req.tema.strip():
        raise HTTPException(status_code=400, detail="Tema diperlukan.")

    # Generate quote
    quote_resp = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{
            "role": "system",
            "content": f"Kamu adalah AI motivasi harian. Tulis satu kutipan motivasi singkat dan inspiratif dalam bahasa Indonesia dengan tema: {req.tema}"
        }],
        max_tokens=60,
        temperature=0.8
    )
    quote = quote_resp.choices[0].message.content.strip()

    prompt = f"Sebuah ilustrasi motivasi dengan tema '{req.tema}', gaya minimalis, warna cerah, sangat inspiratif"

    # Pilih generator gambar
    if req.use_sd and REPLICATE_API_TOKEN:
        image_url = generate_sd_image(prompt)
    else:
        # DALL·E 3
        image_resp = openai.Image.create(
            model="dall-e-3",
            prompt=prompt,
            n=1,
            size="1024x1024"
        )
        image_url = image_resp['data'][0]['url']

    return { "quote": quote, "image": image_url }
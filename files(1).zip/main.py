import requests

REPLICATE_API_TOKEN = os.getenv("REPLICATE_API_TOKEN")

def generate_sd_image(prompt):
    url = "https://api.replicate.com/v1/predictions"
    headers = {
        "Authorization": f"Token {REPLICATE_API_TOKEN}",
        "Content-Type": "application/json",
    }
    body = {
        "version": "a9758cb6bdf367f7e9ea2b4e7c7cf3b4f92d7c4cfb2943a4b5edc8c6c5e0e91a",  # SDXL 1.0
        "input": {"prompt": prompt}
    }
    resp = requests.post(url, headers=headers, json=body)
    prediction = resp.json()
    prediction_url = prediction["urls"]["get"]

    # Polling sampai selesai
    while True:
        poll = requests.get(prediction_url, headers=headers).json()
        if poll["status"] == "succeeded":
            return poll["output"][0]
        if poll["status"] == "failed":
            raise Exception("Stable Diffusion gagal")
        import time; time.sleep(2)

# Di endpoint /generate, ubah bagian generate image:
@app.post("/generate")
async def generate_motivasi(req: TemaRequest):
    # ... generate quote pakai OpenAI seperti biasa
    # Untuk gambar, bisa pilih DALL-E atau SD, contoh SD:
    image_prompt = f"Sebuah ilustrasi motivasi dengan tema '{req.tema}', gaya minimalis, warna cerah, sangat inspiratif"
    image_url = generate_sd_image(image_prompt)
    return { "quote": quote, "image": image_url }